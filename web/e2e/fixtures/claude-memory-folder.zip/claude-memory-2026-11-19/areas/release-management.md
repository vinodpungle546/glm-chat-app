---
name: release-management
description: How releases are run
aliases: [releases]
---
- Weekly release train on Tuesdays.
## Team
- Cian Byrne is the release manager for Project Atlas.
- Mai Tran is a backend developer on the Payments team.
