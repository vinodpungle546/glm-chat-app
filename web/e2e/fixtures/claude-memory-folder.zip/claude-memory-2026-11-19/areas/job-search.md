---
name: job-search
description: Looking at senior QA roles
---
- Interested in test automation leadership roles.
