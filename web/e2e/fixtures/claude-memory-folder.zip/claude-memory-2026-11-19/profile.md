---
name: profile
description: Who the user is
---
- Sam Rivera works as a QA lead on the Payments programme.
- Prefers short answers with tables.
