---
name: Priya Shah
description: Mobile QA lead
aliases: [Priya]
---
- Priya Shah leads the Mobile QA team.
- Prefers async updates.
